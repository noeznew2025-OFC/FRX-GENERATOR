# FARUQ GENERATOR Android

Android project for FARUQ GENERATOR by @FARUQREAL.

## Build
Upload the contents of this directory to the root of a GitHub repository. The workflow at `.github/workflows/build-apk.yml` builds a debug APK and uploads it as an Actions artifact.

## Scope
This app currently provides a local Device ID generator (32-character hexadecimal IDs), local format pass count, result preview, TXT export to `Download/FARUQ GENERATOR`, navigation menu, live monitor, history screen, and thread preference input (1–500).

The original Python source contains automated account-login checking against a third-party game account endpoint, proxy/browser-farm routing, and account detail retrieval. Those remote account-checking and credential-testing functions are not ported. The similarly named menu entries are UI/navigation placeholders or local format-only checks, not server-side account validation.
