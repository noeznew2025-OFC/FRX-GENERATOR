package com.faruq.generator

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.ContentValues
import android.os.Build
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 11, 16)
    private val panel = Color.rgb(20, 24, 33)
    private val red = Color.rgb(255, 61, 87)
    private val white = Color.rgb(244, 246, 250)
    private val muted = Color.rgb(148, 157, 174)
    private val rng = SecureRandom()
    private val results = mutableListOf<String>()
    private lateinit var root: LinearLayout
    private lateinit var monitor: TextView
    private lateinit var preview: TextView
    private lateinit var countInput: EditText
    private lateinit var threadInput: EditText
    private var activeMenu = "GENERATE + CHECK DEV ID"
    private var fileCheckOutput: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun shape(color: Int, radius: Float = 18f, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
        if (stroke != 0) setStroke(1, stroke)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun base(title: String) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(18), dp(18), dp(22)) }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        setContentView(scroll)
        root.addView(text("FARUQ GENERATOR", 25f, white, true))
        root.addView(text("DEVELOPER  @FARUQREAL", 11f, red, true).apply { setPadding(0, dp(3), 0, dp(16) ) })
        root.addView(text(title, 17f, white, true).apply { setPadding(0, 0, 0, dp(12)) })
    }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(14)); background = shape(panel)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    }
    private fun button(label: String, onClick: () -> Unit, primary: Boolean = false): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f; setTextColor(white)
        background = shape(if (primary) red else Color.rgb(37, 43, 55), 14f)
        minHeight = dp(52); minimumHeight = dp(52); setPadding(dp(12), dp(8), dp(12), dp(8))
        setOnClickListener { onClick() }
    }
    private fun addButton(parent: LinearLayout, label: String, onClick: () -> Unit, primary: Boolean = false) {
        parent.addView(button(label, onClick, primary), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
    }
    private fun showHome() {
        base("MAIN MENU")
        val intro = card(); intro.addView(text("DEVICE ID WORKSPACE", 12f, red, true)); intro.addView(text("Generate ID, inspect local files, monitor progress, and export results.", 13f, muted).apply { setPadding(0, dp(6), 0, 0) }); root.addView(intro)
        val menu = listOf("01  GENERATE + CHECK DEV ID", "02  GENERATE ONLY", "03  CHECK VALID (FROM FILE)", "04  CHECK FULL INFO", "05  SETTINGS", "06  HISTORY")
        menu.forEachIndexed { i, item ->
            val c = card(); val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
            row.addView(text(item, 14f, if (i == 0) white else white, true), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text("›", 25f, red, true)); c.addView(row)
            c.setOnClickListener { when(i) { 0 -> showGenerator(true); 1 -> showGenerator(false); 2 -> showFileCheck(); 3 -> showFullInfo(); 4 -> showSettings(); else -> showHistory() } }
            root.addView(c)
        }
        val foot = text("LOCAL DEVICE-ID UTILITIES  •  v1.0", 10f, muted); foot.gravity = Gravity.CENTER; foot.setPadding(0, dp(12), 0, 0); root.addView(foot)
    }
    private fun field(hint: String, value: String): EditText = EditText(this).apply {
        setSingleLine(true); setText(value); setHint(hint); setHintTextColor(muted); setTextColor(white); textSize = 15f
        setPadding(dp(12), dp(10), dp(12), dp(10)); background = shape(Color.rgb(11, 14, 21), 12f, Color.rgb(48, 55, 70))
    }
    private fun showGenerator(withCheck: Boolean) {
        activeMenu = if (withCheck) "GENERATE + CHECK DEV ID" else "GENERATE ONLY"
        base(activeMenu)
        val settings = card(); settings.addView(text("GENERATOR CONTROL", 13f, red, true))
        countInput = field("Jumlah ID", "100"); settings.addView(countInput)
        val threadLabel = text("THREADS (1–500)", 12f, muted, true); threadLabel.setPadding(0, dp(12), 0, dp(5)); settings.addView(threadLabel)
        threadInput = field("Threads", "4"); settings.addView(threadInput)
        root.addView(settings)
        val actions = card(); actions.addView(text("ACTIONS", 13f, red, true))
        addButton(actions, if (withCheck) "GENERATE + CHECK DEV ID" else "GENERATE ONLY", { generateLocal() }, true)
        addButton(actions, "VIEW FILE", { showPreview() })
        addButton(actions, "DOWNLOAD TXT", { downloadTxt() })
        addButton(actions, "RESET", { results.clear(); updateMonitor("Reset selesai"); preview.text = "Belum ada hasil." })
        root.addView(actions)
        val live = card(); live.addView(text("LIVE MONITOR", 13f, red, true))
        monitor = text("Status: READY\nGenerated: 0\nThreads: 4", 13f, muted); monitor.setPadding(0, dp(8), 0, 0); live.addView(monitor)
        root.addView(live)
        val out = card(); out.addView(text("OUTPUT PREVIEW", 13f, red, true)); preview = text("Belum ada hasil.", 12f, muted); preview.setPadding(0, dp(8), 0, 0); out.addView(preview); root.addView(out)
        addButton(root, "‹ BACK TO MENU", { showHome() })
        if (withCheck) { /* Check is intentionally local format validation only; no game-account login or server probing. */ }
    }
    private fun generateLocal() {
        val count = countInput.text.toString().toIntOrNull()?.coerceIn(1, 10000) ?: 100
        val threads = threadInput.text.toString().toIntOrNull()?.coerceIn(1, 500) ?: 4
        results.clear()
        for (i in 1..count) {
            val bytes = ByteArray(16); rng.nextBytes(bytes)
            val id = bytes.joinToString("") { "%02x".format(it) }
            results.add(id)
        }
        val checked = if (activeMenu.contains("CHECK")) results.count { it.matches(Regex("[0-9a-f]{32}")) } else 0
        updateMonitor("Status: COMPLETED\nGenerated: ${results.size}\nLocal format pass: $checked\nThreads setting: $threads")
        preview.text = results.take(8).joinToString("\n") + if (results.size > 8) "\n… ${results.size - 8} more" else ""
    }
    private fun updateMonitor(s: String) { if (::monitor.isInitialized) monitor.text = s }
    private fun showPreview() { preview.text = if (results.isEmpty()) "Belum ada hasil." else results.joinToString("\n") }
    private fun downloadTxt() {
        if (results.isEmpty()) { Toast.makeText(this, "Generate hasil terlebih dahulu", Toast.LENGTH_SHORT).show(); return }
        val name = "faruq_generator_${results.size}.txt"
        try {
            val values = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, "text/plain"); if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Downloads.RELATIVE_PATH, "Download/FARUQ GENERATOR") }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Tidak bisa membuat file")
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(results.joinToString("\n")) }
            Toast.makeText(this, "Tersimpan: Download/FARUQ GENERATOR/$name", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(this, "Gagal menyimpan: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    private fun showFileCheck() {
        base("CHECK VALID (FROM FILE)")
        val c = card(); c.addView(text("LOCAL FILE FORMAT CHECK", 13f, red, true)); c.addView(text("Pilih file TXT untuk memeriksa format Device ID 32 karakter hex. Tidak melakukan login atau validasi akun game.", 12f, muted).apply { setPadding(0, dp(8), 0, 0) })
        addButton(c, "PILIH FILE TXT", { val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(android.content.Intent.CATEGORY_OPENABLE); type = "text/plain" }; startActivityForResult(intent, 410) }, true)
        fileCheckOutput = text("Belum ada file dipilih.", 12f, muted).apply { setPadding(0, dp(10), 0, 0) }; c.addView(fileCheckOutput)
        root.addView(c)
        addButton(root, "BACK", { showHome() })
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 410 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val lines = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readLines() } ?: emptyList()
                val ids = lines.map { it.trim() }.filter { it.isNotEmpty() }
                val valid = ids.count { it.matches(Regex("[0-9a-fA-F]{32}")) }
                val invalid = ids.size - valid
                fileCheckOutput?.text = "File lines: ${ids.size}\nFormat pass: $valid\nFormat fail: $invalid"
            } catch (e: Exception) {
                fileCheckOutput?.text = "Gagal membaca file: ${e.message}"
            }
        }
    }
    private fun showFullInfo() {
        base("CHECK FULL INFO")
        val c = card(); c.addView(text("FULL INFO", 13f, red, true)); c.addView(text("Menu ini disediakan sebagai bagian navigasi. Informasi akun/server game tidak diambil oleh aplikasi ini.", 12f, muted)); root.addView(c)
        addButton(root, "BACK", { showHome() })
    }
    private fun showSettings() {
        base("SETTINGS")
        val c = card(); c.addView(text("THREAD SETTINGS", 13f, red, true)); val t = field("1–500", "4"); c.addView(t); c.addView(text("Batas pengaturan 1 sampai 500. Nilai ini disimpan sebagai preferensi tampilan; generator lokal berjalan ringan.", 12f, muted).apply { setPadding(0, dp(8), 0, 0) }); addButton(c, "SAVE SETTINGS", { val n = t.text.toString().toIntOrNull()?.coerceIn(1,500) ?: 4; getSharedPreferences("faruq", MODE_PRIVATE).edit().putInt("threads", n).apply(); t.setText(n.toString()); Toast.makeText(this, "Threads disimpan: $n", Toast.LENGTH_SHORT).show() }, true); root.addView(c); addButton(root, "BACK", { showHome() })
    }
    private fun showHistory() {
        base("HISTORY")
        val c = card(); c.addView(text("LATEST SESSION", 13f, red, true)); c.addView(text("${results.size} generated ID(s)", 13f, muted)); c.addView(text("${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}", 11f, muted)); root.addView(c); addButton(root, "VIEW RESULTS", { showGenerator(false) }); addButton(root, "BACK", { showHome() })
    }
}
