package com.faruq.gamebooster

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.view.Display
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku

private val Bg = Color(0xFF08090D)
private val Panel = Color(0xFF151821)
private val Red = Color(0xFFFF303B)
private val Muted = Color(0xFF9AA2B2)

class MainActivity : ComponentActivity() {
    private val permissionCode = 4107
    private var shizukuState by mutableStateOf("Memeriksa Shizuku…")
    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == permissionCode) {
            shizukuState = if (grantResult == PackageManager.PERMISSION_GRANTED) "Izin Shizuku aktif" else "Izin Shizuku ditolak"
        }
    }
    private val binderReceived = Shizuku.OnBinderReceivedListener { refreshShizuku() }
    private val binderDead = Shizuku.OnBinderDeadListener { shizukuState = "Shizuku terputus" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListener(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        refreshShizuku()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Red,
                onBackground = Color.White, onSurface = Color.White
            )) {
                BoosterScreen(shizukuState, ::requestShizuku, ::openDisplaySettings)
            }
        }
    }

    private fun refreshShizuku() {
        shizukuState = try {
            when {
                !Shizuku.pingBinder() -> "Shizuku belum berjalan"
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> "Izin Shizuku aktif"
                else -> "Shizuku terhubung — izin diperlukan"
            }
        } catch (_: Exception) { "Shizuku belum tersedia" }
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
                shizukuState = "Jalankan Shizuku, lalu kembali ke aplikasi"
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                refreshShizuku()
            } else {
                Shizuku.requestPermission(permissionCode)
            }
        } catch (e: Exception) {
            shizukuState = "Gagal meminta izin: ${e.message ?: "unknown"}"
        }
    }

    private fun openDisplaySettings() {
        try { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        super.onDestroy()
    }
}

@Composable
private fun BoosterScreen(
    shizukuState: String,
    onShizuku: () -> Unit,
    onDisplaySettings: () -> Unit
) {
    val context = LocalContext.current
    var gamePackage by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Pilih game untuk mulai.") }
    var memory by remember { mutableStateOf(readMemory(context)) }
    var battery by remember { mutableStateOf(readBattery(context)) }
    var showGames by remember { mutableStateOf(false) }
    val games = remember { installedLaunchableApps(context) }

    LaunchedEffect(Unit) {
        while (true) {
            memory = readMemory(context)
            battery = readBattery(context)
            kotlinx.coroutines.delay(2500)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF17101A), Bg, Bg))
        ),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("FARUQ // GAMING LAB", color = Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("GAME BOOSTER", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Black)
            Text("BY FARUQ  •  ROG EDITION", color = Muted, fontSize = 11.sp)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("RAM TERPAKAI", memory, Modifier.weight(1f))
                StatCard("BATTERY", battery, Modifier.weight(1f))
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Text("SHIZUKU STATUS", color = Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(Modifier.height(7.dp))
                Text(shizukuState, color = Color.White, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onShizuku, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                    Text("HUBUNGKAN / CEK IZIN SHIZUKU", color = Color.White)
                }
                Text("Shizuku memakai izin ADB/shell yang disetujui pengguna. Izin bukan akses root.",
                    color = Muted, fontSize = 10.sp)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Text("GAME LAUNCHER", color = Red, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = gamePackage, onValueChange = { gamePackage = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Package game (contoh: com.dts.freefireth)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Red, unfocusedBorderColor = Muted,
                        focusedLabelColor = Red, cursorColor = Red
                    )
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { showGames = !showGames }, modifier = Modifier.weight(1f)) {
                        Text(if (showGames) "TUTUP DAFTAR" else "LIHAT APLIKASI")
                    }
                    Button(onClick = {
                        val pkg = gamePackage.trim()
                        val launch = if (pkg.isNotEmpty()) context.packageManager.getLaunchIntentForPackage(pkg) else null
                        if (launch != null) {
                            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(launch)
                            message = "Membuka $pkg"
                        } else message = "Game tidak ditemukan atau tidak memiliki launcher."
                    }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                        Text("MAIN")
                    }
                }
                if (showGames) {
                    Spacer(Modifier.height(8.dp))
                    games.take(30).forEach { (label, pkg) ->
                        Text("$label  •  $pkg", color = Color.White, fontSize = 12.sp,
                            modifier = Modifier.fillMaxWidth().clickable { gamePackage = pkg }.padding(vertical = 6.dp))
                    }
                    if (games.isEmpty()) Text("Tidak ada aplikasi launcher terdeteksi.", color = Muted)
                }
                Text(message, color = Muted, fontSize = 11.sp)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Text("QUICK OPTIMIZATION", color = Red, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                ActionRow("Refresh rate & display", "Buka pengaturan layar perangkat", onDisplaySettings)
                ActionRow("Battery & power", "Lihat pengaturan baterai", {
                    try { context.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }
                    catch (_: Exception) { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }
                })
                ActionRow("App details", "Kelola izin dan penggunaan aplikasi", {
                    try { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(android.net.Uri.parse("package:${context.packageName}"))) }
                    catch (_: Exception) { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }
                })
            }
        }
        item {
            Text("Catatan: aplikasi ini memantau RAM/baterai dan menyediakan shortcut pengaturan. Kontrol refresh rate global, suhu, FPS, dan mode performa bergantung pada dukungan serta batasan tiap merek/versi Android.",
                color = Muted, fontSize = 10.sp)
            Text("GAME BOOSTER BY FARUQ  •  VERSION 1.0", color = Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) {
        Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun ActionRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        Text("OPEN  ›", color = Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
    HorizontalDivider(color = Color(0xFF303542))
}

private fun readMemory(context: Context): String {
    val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val info = ActivityManager.MemoryInfo()
    manager.getMemoryInfo(info)
    val used = info.totalMem - info.availMem
    return "${used / 1024 / 1024} MB"
}

private fun readBattery(context: Context): String {
    val manager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val level = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    return if (level in 0..100) "$level%" else "N/A"
}

private fun installedLaunchableApps(context: Context): List<Pair<String, String>> {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return context.packageManager.queryIntentActivities(intent, 0)
        .map { it.loadLabel(context.packageManager).toString() to it.activityInfo.packageName }
        .distinctBy { it.second }
        .sortedBy { it.first.lowercase() }
}
