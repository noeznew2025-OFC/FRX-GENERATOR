# GAME BOOSTER BY FARUQ

Project Android Kotlin + Jetpack Compose dengan tema ROG hitam-merah dan integrasi Shizuku API.

## Isi versi 1.0
- Dashboard ROG.
- Monitor RAM dan baterai (refresh otomatis).
- Status Shizuku dan permintaan izin.
- Launcher aplikasi/game.
- Shortcut pengaturan layar dan baterai.
- Tidak melakukan force-stop aplikasi lain, mengubah thermal limit, atau mengklaim menaikkan FPS secara otomatis.

## Persyaratan
- Android Studio terbaru yang mendukung Android Gradle Plugin 8.7.x.
- JDK 17.
- Android SDK Platform 35.
- Koneksi internet saat Gradle pertama kali mengambil dependency.
- Shizuku terpasang untuk menguji bagian integrasi Shizuku.

## Build APK
1. Ekstrak ZIP.
2. Buka folder `GAME_BOOSTER_BY_FARUQ` dari Android Studio.
3. Tunggu Gradle Sync selesai.
4. Pastikan JDK 17 dan Android SDK 35 terpasang.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug akan ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Build melalui terminal (di komputer dengan Android SDK)
```bash
gradle assembleDebug
```
Atau setelah menambahkan Gradle Wrapper dari Android Studio:
```bash
./gradlew assembleDebug
```

## Cara menguji Shizuku
1. Instal dan jalankan Shizuku.
2. Pada Android 11+, aktifkan Developer options dan Wireless debugging.
3. Jalankan Shizuku melalui instruksi aplikasi Shizuku.
4. Buka GAME BOOSTER BY FARUQ.
5. Tekan tombol **HUBUNGKAN / CEK IZIN SHIZUKU**.
6. Setujui permintaan izin jika muncul.

Shizuku non-root umumnya perlu dijalankan kembali setelah reboot. Izin ADB/shell tidak sama dengan root dan sebagian operasi tetap dibatasi Android/OEM.

## Catatan pengembangan
- `QUERY_ALL_PACKAGES` digunakan untuk menampilkan aplikasi launcher yang terpasang. Jika distribusi ke Google Play, tinjau kebijakan visibilitas paket dan hapus izin ini bila tidak memenuhi syarat.
- Fitur refresh rate hanya membuka pengaturan layar karena kontrol global berbeda antar OEM.
- Penggunaan API Shizuku pada versi ini difokuskan pada koneksi dan permission flow. Operasi privileged lanjutan sebaiknya ditambahkan melalui Shizuku UserService dengan pemeriksaan dukungan perangkat dan konfirmasi pengguna.
- Dependency Shizuku API/provider: 13.1.5.
