package com.faruq.generator

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 5, 16)
    private val panel = Color.rgb(18, 13, 33)
    private val panel2 = Color.rgb(25, 17, 45)
    private val purple = Color.rgb(151, 35, 255)
    private val purple2 = Color.rgb(92, 13, 214)
    private val white = Color.rgb(246, 240, 255)
    private val muted = Color.rgb(177, 157, 205)
    private val green = Color.rgb(0, 230, 92)
    private val red = Color.rgb(255, 55, 82)
    private val yellow = Color.rgb(255, 190, 35)
    private val rng = SecureRandom()
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val results = mutableListOf<String>()
    private val history = mutableListOf<String>()
    private lateinit var root: LinearLayout
    private lateinit var monitorBox: LinearLayout
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var countLabel: TextView
    private lateinit var threadLabel: TextView
    private var countValue = 100
    private var threadValue = 50
    private var generationRunning = false
    private var activeMenu = "GENERATE + CHECK VALID"
    private var selectedFormat = "and"
    private var currentFileText: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        val p = getSharedPreferences("faruq", MODE_PRIVATE)
        countValue = p.getInt("count", 100).coerceIn(1, 10000)
        threadValue = p.getInt("threads", 50).coerceIn(1, 500)
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Float = 18f, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius.toInt()).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun gradient(radius: Float = 16f) = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(purple, purple2)).apply { cornerRadius = dp(radius.toInt()).toFloat() }
    private fun txt(s: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun base(title: String, back: Boolean = true) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(24)); setBackgroundColor(bg) }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        setContentView(scroll)
        if (back) {
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val b = txt("‹", 32f, white, true).apply { setPadding(dp(3), 0, dp(16), 0); setOnClickListener { showHome() } }
            head.addView(b); head.addView(txt(title, 18f, white, true)); root.addView(head)
            root.addView(space(12))
        }
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun card(parent: LinearLayout = root, pad: Int = 14): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(pad), dp(pad), dp(pad), dp(pad)); background = shape(panel, 18f, Color.rgb(66, 28, 105))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) }; parent.addView(this)
    }
    private fun button(label: String, primary: Boolean = false, onClick: () -> Unit): TextView = txt(label, 14f, white, true).apply {
        gravity = Gravity.CENTER; minHeight = dp(48); setPadding(dp(12), dp(10), dp(12), dp(10)); background = if (primary) gradient() else shape(Color.rgb(17, 12, 29), 14f, purple)
        setOnClickListener { onClick() }
    }
    private fun addBtn(parent: LinearLayout, label: String, primary: Boolean = false, action: () -> Unit) {
        parent.addView(button(label, primary, action), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
    }
    private fun section(parent: LinearLayout, label: String) { parent.addView(txt(label, 12f, purple, true).apply { setPadding(0, 0, 0, dp(9)) }) }

    private fun showHome() {
        base("", false)
        val hero = card(pad = 15)
        hero.gravity = Gravity.CENTER
        val logo = ImageView(this).apply { setImageResource(R.drawable.faruq_logo); scaleType = ImageView.ScaleType.FIT_CENTER }
        hero.addView(logo, LinearLayout.LayoutParams(dp(190), dp(160)))
        hero.addView(txt("FARUQ", 30f, white, true).apply { gravity = Gravity.CENTER; letterSpacing = .05f })
        hero.addView(txt("GENERATOR", 23f, purple, true).apply { gravity = Gravity.CENTER })
        hero.addView(txt("— @FARUQREAL —", 11f, muted, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(3), 0, dp(10)) })
        hero.addView(txt("◉  Dev ID : ${sampleId()}\n●  Status : READY", 12f, green, true).apply { setPadding(dp(12), dp(9), dp(12), dp(9)); background = shape(Color.rgb(9, 7, 18), 12f, Color.rgb(75, 35, 122)) })
        root.addView(hero)
        root.addView(txt("MAIN MENU", 18f, white, true)); root.addView(txt("Pilih menu yang ingin digunakan", 11f, muted).apply { setPadding(0, dp(3), 0, dp(12)) })
        val names = listOf("⚡   1. GENERATE + CEK VALID" to "Generate sekaligus cek format ID", "✚   2. GENERATE ONLY" to "Hanya generate", "▤   3. CEK VALID (FROM FILE)" to "Cek format Device ID dari file", "ⓘ   4. CEK FULL INFO" to "Informasi hasil lokal", "⚙   5. SETTINGS" to "Atur jumlah & thread", "◴   6. HISTORY" to "Lihat riwayat hasil")
        names.forEachIndexed { i, pair ->
            val c = card(pad = 13)
            c.addView(txt(pair.first, 13f, white, true)); c.addView(txt(pair.second, 10f, muted).apply { setPadding(dp(29), dp(4), 0, 0) })
            c.setOnClickListener { when (i) { 0 -> showGenerator(true); 1 -> showGenerator(false); 2 -> showFileCheck(); 3 -> showFullInfo(); 4 -> showSettings(); else -> showHistory() } }
        }
        root.addView(txt("♛  DEVELOPER : @FARUQREAL  ♛", 10f, purple, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) })
    }

    private fun showGenerator(withCheck: Boolean) {
        activeMenu = if (withCheck) "GENERATE + CEK VALID" else "GENERATE ONLY"
        base(activeMenu)
        val controls = card(); section(controls, "GENERATOR CONTROL")
        countLabel = txt("Jumlah Generate : $countValue", 13f, white, true); controls.addView(countLabel)
        val countSeek = SeekBar(this).apply { max = 9999; progress = countValue - 1; progressTintList = android.content.res.ColorStateList.valueOf(purple); thumbTintList = android.content.res.ColorStateList.valueOf(purple) }
        controls.addView(countSeek); countSeek.setOnSeekBarChangeListener(seek { countValue = it + 1; countLabel.text = "Jumlah Generate : $countValue" })
        threadLabel = txt("Thread : $threadValue", 13f, white, true).apply { setPadding(0, dp(10), 0, 0) }; controls.addView(threadLabel)
        val threadSeek = SeekBar(this).apply { max = 499; progress = threadValue - 1; progressTintList = android.content.res.ColorStateList.valueOf(purple); thumbTintList = android.content.res.ColorStateList.valueOf(purple) }
        controls.addView(threadSeek); threadSeek.setOnSeekBarChangeListener(seek { threadValue = it + 1; threadLabel.text = "Thread : $threadValue" })
        root.addView(controls)
        val format = card(); section(format, "FORMAT DEVICE ID")
        val radios = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("and" to "and_", "ios" to "ios_", "mixed" to "mixed").forEach { (v, label) ->
            val rb = RadioButton(this).apply { text = label; textSize = 12f; setTextColor(white); buttonTintList = android.content.res.ColorStateList.valueOf(purple); isChecked = v == selectedFormat; setOnClickListener { selectedFormat = v } }
            radios.addView(rb)
        }
        format.addView(radios); root.addView(format)
        addBtn(root, if (withCheck) "▶  MULAI GENERATE + CEK FORMAT" else "▶  MULAI GENERATE", true) { startGeneration(withCheck) }
        val live = card(); val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(txt("●  Live Monitor", 13f, green, true), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(txt("CLEAR", 11f, purple, true).apply { setPadding(dp(12), dp(6), dp(12), dp(6)); background = shape(Color.TRANSPARENT, 20f, purple); setOnClickListener { results.clear(); monitorBox.removeAllViews(); progressText.text = "Proses Berjalan...\n0 / $countValue"; progressBar.progress = 0 } })
        live.addView(row)
        monitorBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)); background = shape(Color.rgb(9, 7, 16), 13f, Color.rgb(51, 34, 75)) }
        live.addView(monitorBox)
        progressText = txt("Proses Berjalan...\n0 / $countValue", 11f, muted, true).apply { setPadding(0, dp(10), 0, dp(5)) }; live.addView(progressText)
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = countValue; progress = 0; progressTintList = android.content.res.ColorStateList.valueOf(purple) }; live.addView(progressBar)
        root.addView(live)
        addBtn(root, "▤  VIEW HASIL FILE", false) { showResults() }
        addBtn(root, "⬇  DOWNLOAD TXT", false) { downloadTxt() }
    }
    private fun seek(on: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) on(p) }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun startGeneration(withCheck: Boolean) {
        if (generationRunning) return
        getSharedPreferences("faruq", MODE_PRIVATE).edit().putInt("count", countValue).putInt("threads", threadValue).apply()
        generationRunning = true; results.clear(); monitorBox.removeAllViews(); progressBar.max = countValue; progressBar.progress = 0
        progressText.text = "Proses Berjalan...\n0 / $countValue"
        executor.execute {
            for (i in 1..countValue) {
                val id = generateDeviceId(selectedFormat)
                val ok = isSourceStyleId(id)
                synchronized(results) { results.add(id) }
                handler.post {
                    val line = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(5), dp(4), dp(5)) }
                    val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    top.addView(txt("[%03d/%03d]".format(i, countValue), 11f, Color.rgb(184, 137, 255), true), LinearLayout.LayoutParams(dp(76), -2))
                    top.addView(txt("ID : $id", 10f, white), LinearLayout.LayoutParams(0, -2, 1f))
                    line.addView(top)
                    val state = if (withCheck) if (ok) "FORMAT OK ✓" else "FORMAT INVALID ✕" else "GENERATED ✓"
                    line.addView(txt("     Status : $state", 10f, if (ok) green else red, true))
                    monitorBox.addView(line, 0)
                    if (monitorBox.childCount > 60) monitorBox.removeViewAt(monitorBox.childCount - 1)
                    progressBar.progress = i; progressText.text = "Proses Berjalan...\n$i / $countValue"
                    if (i == countValue) { generationRunning = false; progressText.text = "Selesai ✓\n$countValue / $countValue"; Toast.makeText(this, "Generate selesai: $countValue ID", Toast.LENGTH_SHORT).show(); history.addAll(results.takeLast(200)) }
                }
            }
        }
    }

    // Port of the source generator's weighted format selection and ID templates.
    private fun pickWeighted(): String {
        val n = rng.nextInt(100)
        return when { n < 70 -> "standard"; n < 78 -> "std_upper"; n < 84 -> "short_num"; n < 89 -> "short_aln"; n < 95 -> "hex_only"; else -> "mixed" }
    }
    private fun rand(chars: String, n: Int) = buildString { repeat(n) { append(chars[rng.nextInt(chars.length)]) } }
    private fun uuid(upper: Boolean): String {
        val chars = if (upper) "0123456789ABCDEF" else "0123456789abcdef"
        return listOf(8,4,4,4,12).joinToString("-") { rand(chars, it) }
    }
    private fun androidId(): String = when (pickWeighted()) {
        "standard" -> "and_${rand("0123456789abcdef",32)}${rand("0123456789abcdefghijklmnopqrstuvwxyz",16)}-${uuid(false)}"
        "std_upper" -> "and_${rand("0123456789ABCDEF",32)}${rand("0123456789abcdefghijklmnopqrstuvwxyz",16)}-${uuid(true)}"
        "short_num" -> "and_${rand("0123456789", 1 + rng.nextInt(8))}"
        "short_aln" -> "and_${rand("0123456789abcdefghijklmnopqrstuvwxyz", 4 + rng.nextInt(13))}"
        "hex_only" -> "and_${rand("0123456789abcdef", 20 + rng.nextInt(21))}"
        else -> "and_${rand("0123456789abcdefghijklmnopqrstuvwxyz", 8 + rng.nextInt(17))}-${rand("0123456789abcdef", 8 + rng.nextInt(25))}"
    }
    private fun generateDeviceId(fmt: String): String = when (fmt) {
        "and" -> androidId()
        "ios" -> "ios_${if (rng.nextBoolean()) uuid(true) else uuid(false)}"
        else -> if (rng.nextInt(100) < 80) androidId() else "ios_${if (rng.nextBoolean()) uuid(true) else uuid(false)}"
    }
    private fun isSourceStyleId(s: String) = (s.startsWith("and_") || s.startsWith("ios_")) && s.length >= 15
    private fun sampleId() = "and_" + rand("0123456789abcdef", 12) + "…"

    private fun showResults() {
        base("VIEW HASIL FILE")
        val c = card(); section(c, "OUTPUT DEVICE ID")
        c.addView(txt(if (results.isEmpty()) "Belum ada hasil." else results.joinToString("\n"), 11f, white))
        addBtn(root, "⬇  DOWNLOAD TXT", true) { downloadTxt() }; addBtn(root, "BACK", false) { showHome() }
    }
    private fun downloadTxt() {
        if (results.isEmpty()) { Toast.makeText(this, "Belum ada hasil generate", Toast.LENGTH_SHORT).show(); return }
        try {
            val name = "FARUQ_GENERATOR_${System.currentTimeMillis()}.txt"
            val values = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, "text/plain"); if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Downloads.RELATIVE_PATH, "Download/FARUQ GENERATOR") }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Tidak bisa membuat file")
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(results.joinToString("\n")) }
            Toast.makeText(this, "Tersimpan di Download/FARUQ GENERATOR", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun showFileCheck() {
        base("CEK VALID (FROM FILE)")
        val c = card(); section(c, "PILIH FILE TEXT (.TXT)"); c.addView(txt("Periksa pola Device ID dari file lokal. Hasil ini hanya validasi format, bukan status akun/server.", 12f, muted))
        addBtn(c, "▧  PILIH FILE", true) { val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain" }; startActivityForResult(i, 41) }
        currentFileText = txt("Belum ada file dipilih.", 12f, white).apply { setPadding(0, dp(12), 0, 0) }; c.addView(currentFileText)
        addBtn(root, "BACK", false) { showHome() }
    }
    @Deprecated("legacy picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                val lines = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readLines() } ?: emptyList()
                val ids = lines.map { it.trim() }.filter { it.isNotEmpty() }
                val valid = ids.count { isSourceStyleId(it) }; val invalid = ids.size - valid
                currentFileText?.text = "File berisi ${ids.size} Device ID\nFormat OK: $valid\nFormat INVALID: $invalid\nStatus BAN: tidak diperiksa"
            } catch (e: Exception) { currentFileText?.text = "Gagal membaca file: ${e.message}" }
        }
    }
    private fun showFullInfo() {
        base("CEK FULL INFO")
        val c = card(); section(c, "INFO YANG TERSEDIA"); listOf("✓  Device ID", "✓  Pola / prefix", "✓  Status format", "—  Informasi akun/server", "—  Status ban (tidak diperiksa)").forEach { c.addView(txt(it, 12f, if (it.startsWith("✓")) green else muted).apply { setPadding(0, dp(5), 0, dp(5)) }) }
        addBtn(root, "BACK", false) { showHome() }
    }
    private fun showSettings() {
        base("SETTINGS")
        val c = card(); section(c, "PENGATURAN")
        val n = EditText(this).apply { setText(countValue.toString()); setTextColor(white); hint = "Jumlah generate"; setSingleLine(); background = shape(Color.rgb(12,8,22), 10f, purple); setPadding(dp(12), dp(8), dp(12), dp(8)) }; c.addView(txt("Jumlah Generator", 12f, white, true)); c.addView(n)
        val t = EditText(this).apply { setText(threadValue.toString()); setTextColor(white); hint = "Thread 1–500"; setSingleLine(); background = shape(Color.rgb(12,8,22), 10f, purple); setPadding(dp(12), dp(8), dp(12), dp(8)) }; c.addView(txt("Jumlah Thread (1–500)", 12f, white, true).apply { setPadding(0, dp(12), 0, dp(5)) }); c.addView(t)
        addBtn(c, "♧  SIMPAN PENGATURAN", true) { countValue = (n.text.toString().toIntOrNull() ?: 100).coerceIn(1,10000); threadValue = (t.text.toString().toIntOrNull() ?: 50).coerceIn(1,500); getSharedPreferences("faruq", MODE_PRIVATE).edit().putInt("count",countValue).putInt("threads",threadValue).apply(); Toast.makeText(this,"Pengaturan disimpan",Toast.LENGTH_SHORT).show() }
        addBtn(c, "RESET KE DEFAULT", false) { countValue = 100; threadValue = 50; n.setText("100"); t.setText("50") }
        addBtn(root, "BACK", false) { showHome() }
    }
    private fun showHistory() {
        base("HISTORY")
        val c = card(); section(c, "RIWAYAT GENERATE")
        val data = (history + results).distinct().takeLast(100).reversed()
        c.addView(txt(if (data.isEmpty()) "Belum ada riwayat." else data.joinToString("\n\n") { "${it}\nGENERATED  •  ${SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date())}" }, 11f, white))
        addBtn(c, "HAPUS HISTORY", false) { history.clear(); results.clear(); showHistory() }
        addBtn(root, "BACK", false) { showHome() }
    }
    override fun onDestroy() { super.onDestroy(); executor.shutdownNow() }
}
