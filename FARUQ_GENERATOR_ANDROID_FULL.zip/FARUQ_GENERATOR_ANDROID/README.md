# FARUQ GENERATOR — Android project

Developer label: **@FARUQREAL**

## Included
- Neon-purple Android UI based on the supplied reference image.
- Six main-menu entries: Generate + Cek Valid, Generate Only, Cek Valid (From File), Cek Full Info, Settings, History.
- Original Device ID generator templates and weighted format selection ported from `zelz_generatev6Stable.py` (`and_`, `ios_`, `mixed`).
- Per-ID Live Monitor with sequence number, ID, progress, and immediate output rows.
- View results and export TXT to `Download/FARUQ GENERATOR`.
- Generator count setting (1–10,000) and thread setting (1–500).
- Included logo asset and app launcher icon.

## Important scope note
The original Python source also contains automated network login/session requests to the MLBB game service, account/session inspection, and ban-status probing. Those remote account/server-checking operations are **not included** in this Android project. The `Generate + Cek Valid` screen runs the original-style ID generation and local prefix/format check only. `FORMAT OK` is not a server-confirmed VALID account/device status, and BAN status is not checked. The thread control is retained in the UI/settings but is not used to launch remote checks.

## Build APK with GitHub Actions
1. Upload the contents of this folder to the root of a GitHub repository (not the parent folder).
2. Open **Actions** → **Build FARUQ GENERATOR APK** → **Run workflow**.
3. Download artifact `FARUQ-GENERATOR-APK` after the workflow succeeds.

You can also build locally with Gradle 8.9 and JDK 17:

```bash
gradle assembleDebug
```
