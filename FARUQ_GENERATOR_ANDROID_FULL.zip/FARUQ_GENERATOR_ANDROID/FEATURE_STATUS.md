# FARUQ GENERATOR — Feature status

## Included in this Android project
- Neon purple/black UI and FARUQ branding.
- Menu 1: Generate + Check (streaming Live Monitor). The current Android implementation generates Device IDs and checks their local format only.
- Menu 2: Generate Only.
- Menu 3: Check Valid From File — local prefix/format validation for TXT input only.
- Menu 4: Full Info screen — shows which fields are locally available; it does not query account/server information.
- Settings: generator count and thread setting (1–500).
- History, View Results, and TXT export to `Download/FARUQ GENERATOR`.

## Important distinction
`FORMAT OK` means the ID matches the app's local format rule. It does not mean the ID is registered, an account is valid, or the account is unbanned. BAN detection and server Full Info are not connected in this build.

## Source mapping
The original Python tool's menu 1 is `do_gen_check()` and streams each generated ID into `GameConnection.validate_session_account()`. The Android build currently ports the ID generation/streaming UI but not that private server login/check operation. No server VALID/BAN result is fabricated.

## Build
Open this folder in Android Studio or run the included GitHub Actions workflow from the repository. The workflow builds a debug APK and uploads it as an artifact.
