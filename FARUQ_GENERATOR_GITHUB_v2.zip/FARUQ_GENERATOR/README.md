# FARUQ GENERATOR

Android project for a local device-ID generator with a live progress monitor, in-app result viewer, and TXT download.

- App name: FARUQ GENERATOR
- Developer label: @FARUQREAL
- Android min SDK: 23
- Build: GitHub Actions (`.github/workflows/build.yml`) or `gradle assembleDebug`

## Output file
- On Android 10 and newer, **DOWNLOAD TXT** saves automatically to `Download/FARUQ GENERATOR/`.
- On Android 6–9, Android's file picker asks where to save the TXT file.
- **VIEW FILE** opens the saved TXT file when a compatible viewer is installed. Otherwise, it displays all generated results inside the app.

## GitHub build
1. Upload the contents of this folder to a GitHub repository.
2. Open **Actions** and run **Build FARUQ GENERATOR APK**, or push to `main`/`master`.
3. Download the `FARUQ-GENERATOR-debug-apk` artifact from the workflow run.

## Scope
This build performs local ID generation only. Online game-server session validation, account lookup, and ban-status probing are not included.

### Thread settings
The app includes a worker setting from 1 to 500. The actual worker pool is limited to the smaller of the selected value and the number of IDs requested. High worker counts can consume substantial memory and CPU; use a modest value on phones.
