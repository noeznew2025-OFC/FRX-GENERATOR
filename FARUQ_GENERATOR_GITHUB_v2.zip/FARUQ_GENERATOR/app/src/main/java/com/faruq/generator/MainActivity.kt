package com.faruq.generator

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.content.ContentValues
import android.provider.MediaStore
import android.app.AlertDialog
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import java.util.UUID
import java.util.Locale
import kotlin.random.Random
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 12, 20)
    private val panel = Color.rgb(22, 26, 40)
    private val accent = Color.rgb(255, 55, 90)
    private val muted = Color.rgb(155, 165, 185)
    private var generated = mutableListOf<String>()
    private var count = 0
    private var savedFileUri: Uri? = null
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var total: TextView
    private lateinit var mode: Spinner
    private lateinit var amount: EditText
    private lateinit var threadCount: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(22, 18, 22, 18) }
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val brand = TextView(this).apply { text = "FARUQ\nGENERATOR"; textSize = 30f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-black", Typeface.BOLD); letterSpacing = .06f }
        body.addView(brand)
        body.addView(label("LOCAL DEVICE ID STUDIO  •  ANDROID"))
        body.addView(space(18))
        body.addView(cardTitle("GENERATOR CONTROL"))
        mode = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Android (and_)", "iOS (ios_)", "Mixed")) }
        body.addView(mode, LinearLayout.LayoutParams(-1, 52))
        amount = EditText(this).apply { setText("100"); hint = "Jumlah ID"; inputType = 2; setTextColor(Color.WHITE); setHintTextColor(muted); setPadding(14, 8, 14, 8); setBackgroundColor(panel) }
        body.addView(amount, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 10 })
        body.addView(label("THREAD SETTINGS • 1–500 WORKERS"))
        threadCount = EditText(this).apply { setText("4"); hint = "Jumlah thread (1-500)"; inputType = 2; setTextColor(Color.WHITE); setHintTextColor(muted); setPadding(14, 8, 14, 8); setBackgroundColor(panel) }
        body.addView(threadCount, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 4 })
        body.addView(label("Thread tinggi dapat membebani perangkat. Sesuaikan dengan kemampuan HP."))
        body.addView(space(12))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val generate = button("GENERATE", accent)
        val clear = button("RESET", Color.rgb(58, 66, 88))
        actions.addView(generate, LinearLayout.LayoutParams(0, 52, 1f).apply { rightMargin = 6 })
        actions.addView(clear, LinearLayout.LayoutParams(0, 52, 1f).apply { leftMargin = 6 })
        body.addView(actions)

        body.addView(space(20))
        body.addView(cardTitle("LIVE MONITOR"))
        total = TextView(this).apply { text = "0"; textSize = 28f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) }
        body.addView(total)
        status = label("READY • Menunggu perintah")
        body.addView(status)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progressTintList = android.content.res.ColorStateList.valueOf(accent); progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.DKGRAY) }
        body.addView(progress, LinearLayout.LayoutParams(-1, 10).apply { topMargin = 12 })
        body.addView(space(18))
        body.addView(cardTitle("OUTPUT PREVIEW"))
        output = TextView(this).apply { text = "Belum ada hasil.\nTekan GENERATE untuk membuat ID secara lokal."; textSize = 12f; setTextColor(Color.rgb(210, 218, 235)); setPadding(14, 14, 14, 14); setBackgroundColor(panel); typeface = Typeface.MONOSPACE }
        body.addView(output, LinearLayout.LayoutParams(-1, 220))
        body.addView(space(12))
        val fileActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val viewFile = button("VIEW FILE", Color.rgb(58, 92, 145))
        val download = button("DOWNLOAD TXT", Color.rgb(30, 145, 112))
        fileActions.addView(viewFile, LinearLayout.LayoutParams(0, 50, 1f).apply { rightMargin = 6 })
        fileActions.addView(download, LinearLayout.LayoutParams(0, 50, 1f).apply { leftMargin = 6 })
        body.addView(fileActions)
        body.addView(space(20))
        body.addView(label("Developer  @FARUQREAL\nFARUQ GENERATOR • v1.0"))

        generate.setOnClickListener { runGeneration() }
        clear.setOnClickListener { generated.clear(); count = 0; progress.progress = 0; total.text = "0"; status.text = "RESET • Data hasil dibersihkan"; output.text = "Belum ada hasil." }
        viewFile.setOnClickListener { viewResults() }
        download.setOnClickListener { downloadResults() }
        setContentView(root)
    }

    private fun runGeneration() {
        val n = amount.text.toString().toIntOrNull()?.coerceIn(1, 100000) ?: 100
        val requestedThreads = threadCount.text.toString().toIntOrNull()?.coerceIn(1, 500) ?: 4
        val workers = minOf(requestedThreads, n)
        val type = mode.selectedItemPosition
        generated.clear(); count = 0; savedFileUri = null
        progress.progress = 0
        status.text = "RUNNING • $n ID | $workers thread aktif"
        output.text = "Memproses..."
        Thread {
            val result = arrayOfNulls<String>(n)
            val completed = AtomicInteger(0)
            val executor = Executors.newFixedThreadPool(workers)
            for (worker in 0 until workers) {
                executor.submit {
                    var index = worker
                    while (index < n) {
                        result[index] = makeId(type)
                        val done = completed.incrementAndGet()
                        if (done % 100 == 0 || done == n) {
                            runOnUiThread {
                                progress.progress = done * 100 / n
                                total.text = String.format(Locale.US, "%d / %d", done, n)
                                status.text = "RUNNING • ${done * 100 / n}% | $done dibuat | $workers thread"
                            }
                        }
                        index += workers
                    }
                }
            }
            executor.shutdown()
            executor.awaitTermination(1, TimeUnit.HOURS)
            val finalResult = result.mapNotNull { it }
            runOnUiThread {
                generated = finalResult.toMutableList()
                count = generated.size
                progress.progress = 100
                total.text = "$count / $n"
                status.text = "COMPLETED • $count ID | $workers thread digunakan"
                output.text = generated.take(30).joinToString("\n") + if (generated.size > 30) "\n...\n(${generated.size - 30} lainnya)" else ""
            }
        }.start()
    }

    private fun makeId(type: Int): String {
        val android = when (Random.nextInt(100)) {
            in 0..69 -> "and_${hex(32)}${alpha(16)}-${uuid(false)}"
            in 70..77 -> "and_${hex(32, true)}${alpha(16)}-${uuid(true)}"
            in 78..83 -> "and_${digits(Random.nextInt(1, 9))}"
            in 84..88 -> "and_${alpha(Random.nextInt(4, 17))}"
            in 89..94 -> "and_${hex(Random.nextInt(20, 41))}"
            else -> "and_${alpha(Random.nextInt(8, 25))}-${hex(Random.nextInt(8, 33))}"
        }
        val ios = "ios_${uuid(Random.nextBoolean())}"
        return when (type) { 0 -> android; 1 -> ios; else -> if (Random.nextInt(100) < 80) android else ios }
    }
    private fun hex(n: Int, upper: Boolean = false) = (1..n).map { "0123456789abcdef".random() }.joinToString("").let { if (upper) it.uppercase() else it }
    private fun alpha(n: Int) = (1..n).map { "0123456789abcdefghijklmnopqrstuvwxyz".random() }.joinToString("")
    private fun digits(n: Int) = (1..n).map { "0123456789".random() }.joinToString("")
    private fun uuid(upper: Boolean): String = UUID.randomUUID().toString().let { if (upper) it.uppercase() else it }

    private fun viewResults() {
        if (generated.isEmpty()) {
            Toast.makeText(this, "Belum ada hasil. Tekan GENERATE dulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val uri = savedFileUri
        if (uri != null) {
            try {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "text/plain")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(intent)
                return
            } catch (_: Exception) {
                // Fall back to the in-app viewer when no text viewer is installed.
            }
        }
        val content = TextView(this).apply {
            text = generated.joinToString("\n")
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.MONOSPACE
            setPadding(24, 16, 24, 16)
        }
        val scroll = ScrollView(this).apply { addView(content) }
        AlertDialog.Builder(this)
            .setTitle("Hasil FARUQ GENERATOR • ${generated.size} ID")
            .setView(scroll)
            .setPositiveButton("TUTUP", null)
            .show()
    }

    private fun downloadResults() {
        if (generated.isEmpty()) {
            Toast.makeText(this, "Belum ada hasil untuk di-download", Toast.LENGTH_SHORT).show()
            return
        }
        val fileName = "faruq_generator_${generated.size}.txt"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/FARUQ GENERATOR")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Tidak bisa membuat file")
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                    it.write(generated.joinToString("\n"))
                } ?: throw IllegalStateException("Tidak bisa menulis file")
                val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                contentResolver.update(uri, done, null, null)
                savedFileUri = uri
                Toast.makeText(this, "Tersimpan: Download/FARUQ GENERATOR/$fileName", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal menyimpan: ${e.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "text/plain"
                putExtra(Intent.EXTRA_TITLE, fileName)
            }
            startActivityForResult(intent, 78)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 78 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                    it.write(generated.joinToString("\n"))
                }
                savedFileUri = uri
                Toast.makeText(this, "File berhasil disimpan", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal menyimpan: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
    private fun label(s: String) = TextView(this).apply { text = s; textSize = 12f; setTextColor(muted); setPadding(0, 6, 0, 6) }
    private fun cardTitle(s: String) = TextView(this).apply { text = s; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(accent); setPadding(0, 8, 0, 8) }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }
    private fun button(s: String, color: Int) = Button(this).apply { text = s; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(color) }
}
